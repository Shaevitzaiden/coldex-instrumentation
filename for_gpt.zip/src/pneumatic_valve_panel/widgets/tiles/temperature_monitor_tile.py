from __future__ import annotations

from PyQt5 import QtCore, QtWidgets

from ...data.data_hub import DataHub
from ...data.models import SensorDefinition, SensorFrame
from .tile_base import TileWidget


class TemperatureMonitorTile(TileWidget):
    def __init__(
            self,
            *,
            tile_id: str,
            title: str,
            data_hub: DataHub,
            sensor_definitions: dict[str, SensorDefinition],
            channels: list[str],
            removable: bool = True
    ) -> None:
        
        # References to application sensor configuration
        self.data_hub = data_hub
        self.sensor_defintions = sensor_definitions

        # Only keep channels that actually exist in sensors.yaml
        self.channels = [
            channel for channel in channels if channel in sensor_definitions
        ]

        self._value_labels: dict[str, QtWidgets.QLabel] = {}

        # Build the interior widget that will be placed inside TileWidget
        content = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(content)

        # Create one visual temperature block per configured channel.
        for channel in self.channels:
            definition = sensor_definitions[channel]

            sensor_widget = self._create_sensor_display(
                channel,
                definition,
            )

            layout.addWidget(sensor_widget)

        # Push the sensor displays toward the top if there is excess room
        layout.addStretch(1)

        # TileWidget supplues the standward dashboard frame/header and dashboard edit controls
        super().__init__(
            tile_id=tile_id,
            title=title,
            child=content,
            removable=removable
        )

        # Connect to datahub for updates
        self.data_hub.frame_received(self.on_frame)

        # Populate values immediately from datahub
        self._populate_existing_values()

    def _create_sensor_display(
            self,
            channel: str,
            definitions: SensorDefinition,
            ) -> QtWidgets.QWidget:

        container = QtWidgets.QFrame()
        container.setFrameShape(QtWidgets.QFrame.StyledPanel)

        layout = QtWidgets.QVBoxLayout(container)

        # Human readable sensor name from sensors.yaml
        name_label = QtWidgets.QLabel(definitions.label)
        name_label.setAlignment(QtCore.Qt.AlignCenter)

        # Large numeric value
        value_label = QtWidgets.QLabel("—")
        value_label.setAlignment(QtCore.Qt.AlignCenter)

        value_font = value_label.font()
        value_font.setPointSize(24)
        value_font.setBold(True)
        value_label.setFont(value_font)

        # Unit is also defined centrall in sensors.yaml
        unit_label = QtWidgets.QLabel(definitions.unit)
        unit_label.setAlignment(QtCore.Qt.AlignCenter)

        layout.addWidget(name_label)
        layout.addWidget(value_label)
        layout.addWidget(unit_label)

        self._value_labels[channel] = value_label

        return container

    def _populate_existing_values(self) -> None:
        """Populate displays from Datahub's latest-value cache"""
        for channel in self.channels:
            value = self.data_hub.latest_values.get(channel)
            if value is not None:
                self._set_value(channel, value)

    @QtCore.pyqtSlot(object)
    def on_frame(self, frame: SensorFrame) -> None:
        """Process one normalized frame delivered by DataHub.
        A frame may contain many channels, and most frames will contain channels that this tile does not care about.  
        Only update the channels that are configured for this tile,
        This is done in __value_labels, which is a dict of channel -> QLabel for the value display.
        """
        for channel, value in frame.values.items():
            # Is this one of our configured temperature channels?
            if channel not in self._value_labels:
                continue

            self._set_value(channel, value)

    def _set_value(self, channel:str, value: float) -> None:
        """Update on displayed sensor value"""
        label = self._value_labels.get(channel)

        if label is None:
            return

        label.setText(f"{value:0.1f}")

